papyrus
=======

Papyrus Icon Theme


Installing
==========

Installing Papyrus Icon Theme ist straight forward. If you want the theme to be available for all users of your PC,
copy all Papyrus folders to /usr/share/icons.
If you want it to be available only for yourself, copy to ~/.icons (in your home directory).

The easiest way of installing is by using the script. It will lead you through the process
and will edit the themes files to go smootheley with your chosen GTK+ theme.

Just run ./INSTALL.sh from the command line, within the Papyrus-Icon-Theme folder.
Run as root to install for all users.



Changelog
=========

2015-04-28 0.1 Initial Release
